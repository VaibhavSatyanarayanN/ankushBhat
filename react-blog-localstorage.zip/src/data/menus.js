export const menus = [
    {
        id:1,
        name:`Home`,
        link:`/`
    },
    {
        id:2,
        name:`Post`,
        link:`/blogs`
    },
    {
        id:3,
        name:`About`,
        link:`/about`
    },

]